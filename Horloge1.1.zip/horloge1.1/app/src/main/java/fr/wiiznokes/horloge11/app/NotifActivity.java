package fr.wiiznokes.horloge11.app;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import fr.wiiznokes.horloge11.R;

public class NotifActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notif);

    }
}